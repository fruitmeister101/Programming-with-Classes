# CSE 210 Prepare Source Code
This repo contains the incomplete source code for the CSE 210 preparation 
assignments and the Articulate competency.

It should be cloned by each person in the class and used as directed on the 
prepare assignment page.